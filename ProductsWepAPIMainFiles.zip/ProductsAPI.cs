﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DotNetModuleExamWebAPI.Models
{
    public class ProductsAPI 
    {
        public int ProductId { get; set; }

        public decimal Rate { get; set; }

        public string ProductName { get; set; }

        public string Description { get; set; }

        public string CategoryName { get; set; }
    }
}