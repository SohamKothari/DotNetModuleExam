﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace EndModuleExam1.Models
{
    public class ProductsMOD
    {
        [Key]
        public int ProductId { get; set; }
        
        [DataType(DataType.Text)]
        [Required(ErrorMessage ="# Product Name not filled !!!!")]
        public string ProductName { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "# Rate not filled !!!!")]
        [Range(0,int.MinValue,ErrorMessage ="# Rate cannot be Zero !!")]
        public decimal Rate { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "# Description not filled !!!!")]
        public string Description { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "# Category not filled !!!!")]
        public string CategoryName { get; set; }
        
    }
}